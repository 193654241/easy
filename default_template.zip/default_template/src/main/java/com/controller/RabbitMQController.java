package com.controller;

import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Controller
@CrossOrigin
public class RabbitMQController {
    @Autowired
    AmqpTemplate amqpTemplate;

    @PostMapping("/add/1")
    @ResponseBody
    public String add() {
//        MessageProperties messageProperties = new MessageProperties();
//        Message message = new Message("123".getBytes(), messageProperties);
//        amqpTemplate.send("testExchange", "testQueue",message);
        for (int i = 0; i < 10000; i++) {
            //发送10000个消息到rabbitmq消息中间件的某Routing key是tt的队列且是绑定testExchange交换机的队列
            amqpTemplate.convertAndSend("testExchange", "tt", i);
        }
//        amqpTemplate.send(message);
        return "成功";
    }

    @PostMapping("/add/2")
    @ResponseBody
    public String get() {
        Integer tt = (Integer) amqpTemplate.receiveAndConvert("testQueue");
        do {
            Integer next = (Integer) amqpTemplate.receiveAndConvert("testQueue");
            if (tt != null && next != null) {
                if (tt != next - 1) {
                    System.out.println(tt);
                    tt = next;
                }
            } else {
                break;
            }
        } while (tt != null);
        return "成功2";
    }

    //    @GetMapping("/delete/{data}")
//    public void delete(@PathVariable String data){
//        amqpTemplate.convertAndSend();
//    }
    @PostMapping("/add/3")
    @ResponseBody
    public String getT() {
        for (int i = 0; i < 10; i++) {
            Object o = amqpTemplate.receiveAndConvert("testQueue");
            if (o != null) {
                System.out.println("======= o" + o);
                Integer tt = (Integer) o;
                System.out.println("========= tt" + tt.toString());
            }
        }
        return "成功3";
    }

    @PostMapping("/add/4")
    @ResponseBody
    public String get4(@RequestBody Map map) {
        amqpTemplate.convertAndSend("testExchange", "tt", map);
        return "成功4";
    }
}