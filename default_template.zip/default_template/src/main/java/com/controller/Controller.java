﻿package ${package}.controller;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;

import ${package}.pojo.${cname};
import ${package}.service.${cname}Service;

import ${package}.entity.PageResult;

/**
 * ${name}控制器层
 * @author Administrator
 *
 */
@RestController
@CrossOrigin
@RequestMapping("/${name}")
public class ${cname}Controller {

	@Autowired
	private ${cname}Service ${name}Service;
	
	
	/**
	 * 查询全部数据
	 * @return
	 */
	@RequestMapping(method= RequestMethod.GET)
	public ResponseEntity findAll(){
		return ResponseEntity.ok().body(${name}Service.findAll());
	}
	
	/**
	 * 根据ID查询
	 * @param id ID
	 * @return
	 */
	@RequestMapping(value="/{id}",method= RequestMethod.GET)
	public ResponseEntity findById(@PathVariable String id){
		return ResponseEntity.ok().body(${name}Service.findById(id));
	}


	/**
	 * 分页+多条件查询
	 * @param searchMap 查询条件封装
	 * @param page 页码
	 * @param size 页大小
	 * @return 分页结果
	 */
	@RequestMapping(value="/search/{page}/{size}",method=RequestMethod.POST)
	public ResponseEntity findSearch(@RequestBody Map searchMap , @PathVariable int page, @PathVariable int size){
		Page<${cname}> pageList = ${name}Service.findSearch(searchMap, page, size);
		return ResponseEntity.ok().body(new PageResult<${cname}>(pageList.getTotalElements(), pageList.getContent()));
	}

	/**
     * 根据条件查询
     * @param searchMap
     * @return
     */
    @RequestMapping(value="/search",method = RequestMethod.POST)
    public ResponseEntity findSearch( @RequestBody Map searchMap){
	return ResponseEntity.ok().body(${name}Service.findSearch(searchMap));
    }
	
	/**
	 * 增加
	 * @param ${name}
	 */
	@RequestMapping(method=RequestMethod.POST)
	public ResponseEntity add(@RequestBody ${cname} ${name}  ){
		${name}Service.add(${name});
		return ResponseEntity.ok("增加成功");
	}
	
	/**
	 * 修改
	 * @param ${name}
	 */
	@RequestMapping(value="/{id}",method= RequestMethod.PUT)
	public ResponseEntity update(@RequestBody ${cname} ${name}, @PathVariable String id ){
		${name}.setId(id);
		${name}Service.update(${name});
		return ResponseEntity.ok("修改成功");
	}
	
	/**
	 * 删除
	 * @param id
	 */
	@RequestMapping(value="/{id}",method= RequestMethod.DELETE)
	public ResponseEntity delete(@PathVariable String id ){
		${name}Service.deleteById(id);
		return ResponseEntity.ok("删除成功");
	}
	
}
