﻿package ${package}.pojo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
/**
 * ${name}实体类
 * @author Administrator
 *
 */
@Entity
@Table(name="${name}")
public class ${cname} implements Serializable{

${columns}

${getsets}

}
