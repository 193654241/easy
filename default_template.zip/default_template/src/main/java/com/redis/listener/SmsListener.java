﻿package ${package}.redis.listener;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.Map;

@Component
@RabbitListener(queues = "testQueue")//监听哪个消息队列
public class SmsListener {

    @RabbitHandler
    public void executeSms(Map map) {//传入的什么数据类型，这里形参就用什么类型接收和处理
        Iterator iterator = map.keySet().iterator();
        while (iterator.hasNext()){
            String s = iterator.next().toString();
            System.out.println(s);
            System.out.println(map.get(s));
        }
    }
}
