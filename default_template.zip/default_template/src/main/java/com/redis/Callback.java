﻿package ${package}.redis;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.core.ReceiveAndReplyMessageCallback;
//暂时用不上本类
public class Callback implements ReceiveAndReplyMessageCallback {
    @Override
    public Message handle(Message message) {
        MessageProperties messageProperties = message.getMessageProperties();
        message.getBody();
        return null;
    }
}