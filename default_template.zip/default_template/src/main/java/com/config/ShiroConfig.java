﻿package ${package}.config;


import ${package}.realm.UserRealm;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;

import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.LinkedHashMap;
import java.util.Map;

@Configuration
public class ShiroConfig {
    //创建ShiroFilterFactoryBean
    @Bean
    public ShiroFilterFactoryBean getShiroFilterFactoryBean(@Qualifier("securityManager") DefaultWebSecurityManager securityManager) {
        ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();
        //设置安全管理器
        shiroFilterFactoryBean.setSecurityManager(securityManager);

        //添加安全管理器
        /**
         * Shiro内置过滤器
         * 常用过滤器
         * anno:无需认证(无需登录)就可以访问
         * authc:必须认证才可以访问
         * user:如果使用rememberMe的功能可以直接访问
         * perms:该资源必须得到资源权限才可以访问
         * role:该资源必须得到角色权限才可以访问
         *          路径前要加 /
         *
         *          filterMap（"/*","authc"）  注意别放在最上面，不然全部请求会被拦截
         * */
        //拦截下面这么请求路径
        Map<String, String> filterMap = new LinkedHashMap<String, String>();
//        filterMap.put("/user/add","authc");
//        filterMap.put("/user/update","authc");
//        filterMap.put("/*","authc");//可以使用通配符，限制所有页面都需要登录访问
        //授权过滤器,第二个参数[]内是授权码，用户在访问页面授权的时候，需要带上这个授权码才可以访问页面
        filterMap.put("/user/update", "perms[user:update]");
        filterMap.put("/admin", "perms[admin]");
        filterMap.put("/admin/*", "perms[admin]");

        shiroFilterFactoryBean.setFilterChainDefinitionMap(filterMap);

        //设置,设置未认证提示页面
        shiroFilterFactoryBean.setLoginUrl("/login");
        //设置,未授权提示页面
        shiroFilterFactoryBean.setUnauthorizedUrl("/unAuth");
        return shiroFilterFactoryBean;
    }


    //创建DefaultWebSecurityManager
    @Bean(name = "securityManager")
    public DefaultWebSecurityManager getDefaultWebSecurityManager(@Qualifier("userRealm") UserRealm userRealm) {
        DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
        //关联Realm
        securityManager.setRealm(userRealm);
        return securityManager;
    }

    //创建Realm
    @Bean(name = "userRealm")
    public UserRealm getRealm() {
        return new UserRealm();
    }
}
