﻿package ${package}.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import ${package}.pojo.${cname};
/**
 * ${name}数据访问接口
 * @author Administrator
 *
 */
public interface ${cname}Dao extends JpaRepository<${cname},String>,JpaSpecificationExecutor<${cname}>{
	
}
